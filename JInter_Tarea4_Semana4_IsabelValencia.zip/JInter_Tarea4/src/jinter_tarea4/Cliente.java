/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jinter_tarea4;

/**
 *
 * @author Isabel
 */
public class Cliente {
    private int id;
    private String no_nit;
    private String nombre;
    private String direccion;
    private double ingremensual;

    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + ", no_nit=" + no_nit + ", nombre=" + nombre + ", direccion=" + direccion + ", ingremensual=" + ingremensual + '}';
    }
    
 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNo_nit() {
        return no_nit;
    }

    public void setNo_nit(String no_nit) {
        this.no_nit = no_nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getIngremensual() {
        return ingremensual;
    }

    public void setIngremensual(double ingremensual) {
        this.ingremensual = ingremensual;
    }

   
    
    
    
    
}
