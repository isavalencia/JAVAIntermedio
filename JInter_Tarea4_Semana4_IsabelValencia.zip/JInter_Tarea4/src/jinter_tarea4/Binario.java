/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jinter_tarea4;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Isabel
 */
public class Binario {
    
    
    //Escribir Archivo Binario Clientes
     public void escribirAgendaElectronicaBinaria(String noDui, String nombre, String direccion, double ingresosmens){
        try{
            //Abrimos el archivo para guardar informacion
            FileOutputStream fstream = new FileOutputStream(""
                    + "src\\jinter_tarea4\\AgendaElectronicaBinaria.dat", true);
            DataOutputStream archivoSalidaAgenda = new DataOutputStream(fstream);
            
            System.out.println("Escribiendo datos en Agenda Electronica binaria...");
            
            archivoSalidaAgenda.writeUTF(noDui);
            archivoSalidaAgenda.writeUTF(nombre);
            archivoSalidaAgenda.writeUTF(direccion);           
            archivoSalidaAgenda.writeDouble(ingresosmens);
            
            //Cerramos el archivo
            archivoSalidaAgenda.close();
            System.out.println("Se ha escrito datos en Agenda Electronica binaria...");
            System.out.println("�ARCHIVO .DAT CREADO.....REVISA!");
            
        }catch(Exception e){
            System.out.println("Error al escribir");
            e.getMessage();
        }
        
    }
     
     //Leer Archivo Binario Clientes
      public void leerAgendaElectricaBinaria() throws IOException{
        String noDui = "";
        String nombre = "";
        String direccion = "";
        double ingresosmens = 0.00;
        //flag de fin de archivo
        boolean endOfFile = false;
        
        try{
            //Se abre el archivo binario
            FileInputStream fstream = new FileInputStream("src\\jinter_tarea4\\AgendaElectronicaBinaria.dat");
            DataInputStream AgendaElectronicaEntrada = new DataInputStream(fstream);
            
            System.out.println("Lectura de datos en Agenda Electronica binaria...");
                    
            
            //Lectura del archivo binario
            while (!endOfFile){
                try{
                    noDui = AgendaElectronicaEntrada.readUTF();
                    nombre = AgendaElectronicaEntrada.readUTF();
                    direccion = AgendaElectronicaEntrada.readUTF();
                    ingresosmens = AgendaElectronicaEntrada.readDouble();
                    
                    String datosEmpleados = "";
                    
                    datosEmpleados += "  No Dui: " + noDui + "\n" +
                                      "  Nombre: " + nombre + "\n" +
                                      "  Direccion: " + direccion + "\n" +                                     
                                      "  Ingresos Mensuales: " + ingresosmens + "\n";
                    
                }catch(EOFException e){
                    endOfFile = true;
                }
            }
            JOptionPane.showMessageDialog(null, "�ARCHIVO .DAT CREADO CORRECTAMENTE.....REVISA!");
            
            
        }catch(Exception e){
            System.out.println("Error al leer");
            e.printStackTrace();
            e.getMessage();
            
        }
        System.out.println("\n ***Se ha leido datos en Agenda Electronica binaria...");
        
    }
    
    
}
